const mongoose = require('mongoose');
require('dotenv').config();
const Course = require('./models/Course');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/course_site_db';

const data = [
  { title: 'Intro to Web Dev', description: 'HTML, CSS, JS fundamentals', duration: '4 weeks', price: 199 },
  { title: 'Fullstack with MERN', description: 'MongoDB, Express, React, Node', duration: '8 weeks', price: 599 },
  { title: 'Data Structures and Algorithms', description: 'DSA for interviews', duration: '6 weeks', price: 399 }
];

mongoose.connect(MONGO_URI).then(async () => {
  await Course.deleteMany({});
  await Course.insertMany(data);
  console.log('Seeded courses');
  mongoose.disconnect();
});